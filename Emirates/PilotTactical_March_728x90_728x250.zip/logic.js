
var creative = {};

var openFlag = false,
    expandable = true,
    timer;

var tl1 = new TimelineLite();
var tl2 = new TimelineLite();

/**
 * Window onload handler.
 */
function preInit() {
  setupDom();

  if (Enabler.isInitialized()) {
    init();
  } else {
    Enabler.addEventListener(
      studio.events.StudioEvent.INIT,
      init
    );
  }
}

/**
 * Initializes the ad components
 */
function setupDom() {
  creative.dom = {};
  creative.dom.mainContainer = document.getElementById('main-container');
  creative.dom.expandedExit = document.getElementById('expanded-exit');
  creative.dom.expandedContent = document.getElementById('expanded-state');
  creative.dom.collapsedExit = document.getElementById('collapsed-exit');
  creative.dom.collapsedContent = document.getElementById('collapsed-state');
  creative.dom.collapseButton = document.getElementById('collapse-button');
  // creative.dom.expandButton = document.getElementById('expand-button');
  creative.dom.featureCollapsed = document.getElementById('feature-collapsed');
  creative.dom.featureExpanded = document.getElementById('feature-expanded');
}

/**
 * Ad initialisation.
 */
function init() {
  Enabler.setExpandingPixelOffsets(0, 0, 728, 250);
  Enabler.setStartExpanded(false);

  addListeners();

  // Polite loading
  if (Enabler.isVisible()) {
    show();
  }
  else {
    Enabler.addEventListener(studio.events.StudioEvent.VISIBLE, show);
  }
}

/**
 * Adds appropriate listeners at initialization time
 */
function addListeners() {
  Enabler.addEventListener(studio.events.StudioEvent.EXPAND_START, expandStartHandler);
  Enabler.addEventListener(studio.events.StudioEvent.EXPAND_FINISH, expandFinishHandler);
  Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_START, collapseStartHandler);
  Enabler.addEventListener(studio.events.StudioEvent.COLLAPSE_FINISH, collapseFinishHandler);

  // creative.dom.expandButton.addEventListener('click', onExpandHandler, false);
  creative.dom.collapseButton.addEventListener('click', onCollapseBtnClickHandler, false);
  creative.dom.collapseButton.addEventListener('mouseover', function() {openFlag = false;}, false);

  creative.dom.expandedExit.addEventListener('click', exitClickHandler);
  creative.dom.expandedExit.addEventListener('mouseout', preCollapseHandler, false);
  creative.dom.expandedExit.addEventListener('mouseover', function() {openFlag = false;}, false);

  creative.dom.collapsedExit.addEventListener('click', collapsedExitClickHandler);
  creative.dom.collapsedExit.addEventListener('mouseover', onExpandHandler, false);
  creative.dom.collapsedExit.addEventListener('mouseout', function() {expandable = true;}, false);
}

/**
 *  Shows the ad.
 */
function show() {
  creative.dom.expandedContent.style.display = 'none';
  creative.dom.expandedExit.style.display = 'none';
  creative.dom.collapseButton.style.display = 'none';

  creative.dom.collapsedContent.style.display = 'block';
  creative.dom.collapsedExit.style.display = 'block';
  // creative.dom.expandButton.style.display = 'block';
  creative.dom.featureCollapsed.style.visibility  = 'visible';
  creative.dom.featureExpanded.style.visibility  = 'visible';

	init1();
	init2();
}

// ---------------------------------------------------------------------------------
// MAIN
// ---------------------------------------------------------------------------------


function expandStartHandler() {
  // Show expanded content.
  creative.dom.expandedContent.style.display = 'block';
  creative.dom.expandedExit.style.display = 'block';
  creative.dom.collapseButton.style.display = 'block';
  creative.dom.collapsedContent.style.display = 'none';
  creative.dom.collapsedExit.style.display = 'none';
  // creative.dom.expandButton.style.display = 'none';

  Enabler.finishExpand();
}

function expandFinishHandler() {
  creative.isExpanded = true;
	tl2.restart();
}

function collapseStartHandler() {
  // Perform collapse animation.
  creative.dom.expandedContent.style.display = 'none';
  creative.dom.expandedExit.style.display = 'none';
  creative.dom.collapseButton.style.display = 'none';
  creative.dom.collapsedContent.style.display = 'block';
  creative.dom.collapsedExit.style.display = 'block';
  // creative.dom.expandButton.style.display = 'block';

  // When animation finished must call
  Enabler.finishCollapse();
}

function collapseFinishHandler() {
  creative.isExpanded = false;
	tl1.restart();
}

function onCollapseBtnClickHandler() {
  openFlag = true;
  expandable = false;
  onCollapseHandler();
}


function preCollapseHandler() {
  openFlag = true;
  timer = setInterval(onCollapseHandler, 100);
}

function onCollapseHandler(){
  clearInterval(timer);
  if (!openFlag) {
    return;
  }

  Enabler.requestCollapse();
  Enabler.stopTimer('Panel Expansion');
}

function onExpandHandler(){
  if (!expandable) {
    return;
  }

  Enabler.requestExpand();
  Enabler.startTimer('Panel Expansion');
}

function exitClickHandler() {
  clearInterval(timer);
  Enabler.requestCollapse();
  Enabler.stopTimer('Panel Expansion');
  Enabler.exit('BackgroundExit');
}

function collapsedExitClickHandler() {
  Enabler.exit('CollapsedExit');
}

/**
 *  Main onload handler
 */
window.addEventListener('load', preInit);

function init1() {

	tl1.to(f1_text_1, 0.5, {autoAlpha: 1})
    .to(f1_text_1, 0.5, {autoAlpha: 0}, '+=2')
    .to(f1_bg_1, 0.5, {autoAlpha: 0}, '-=0.5')

    .to(f2_bg_1, 0.5, {autoAlpha: 1}, '-=0.5')
    .to(f2_text_1, 0.5, {autoAlpha: 1})
    .to(f2_text_1, 0.5, {autoAlpha: 0}, '+=2')
    .to(f2_bg_1, 0.5, {autoAlpha: 0}, '-=0.5')

    .to(f3_bg_1, 0.5, {autoAlpha: 1}, '-=0.5')
    .to(f3_text1_1, 0.5, {autoAlpha: 1})
    .to(f3_text1_1, 0.5, {autoAlpha: 0}, "+=2")

    .to(f3_text2_1, 0.5, {autoAlpha: 1})
    .to(f3_text2_1, 0.5, {autoAlpha: 0}, "+=2")

    .to(f3_text3_1, 0.5, {autoAlpha: 1})
    .to(f3_text4_1, 0.5, {autoAlpha: 1})
    .to(cta_1, 0.5, {autoAlpha: 1})
    .to(logo_1, 2, {autoAlpha: 1});

}


function init2() {

  tl2.to(f1_text_2, 0.5, {autoAlpha: 1})
    .to(f1_text_2, 0.5, {autoAlpha: 0}, '+=2')
    .to(f1_bg_2, 0.5, {autoAlpha: 0}, '-=0.5')

    .to(f2_bg_2, 0.5, {autoAlpha: 1}, '-=0.5')
    .to(f2_text_2, 0.5, {autoAlpha: 1})
    .to(f2_text_2, 0.5, {autoAlpha: 0}, '+=2')
    .to(f2_bg_2, 0.5, {autoAlpha: 0}, '-=0.5')

    .to(f3_bg_2, 0.5, {autoAlpha: 1}, '-=0.5')
    .to(f3_text1_2, 0.5, {autoAlpha: 1})
    .to(f3_text1_2, 0.5, {autoAlpha: 0}, "+=2")

    .to(f3_text2_2, 0.5, {autoAlpha: 1})
    .to(f3_text2_2, 0.5, {autoAlpha: 0}, "+=2")

    .to(f3_text3_2, 0.5, {autoAlpha: 1})
    .to(f3_text4_2, 0.5, {autoAlpha: 1})
    .to(cta_2, 0.5, {autoAlpha: 1})
    .to(logo_2, 2, {autoAlpha: 1});

}
