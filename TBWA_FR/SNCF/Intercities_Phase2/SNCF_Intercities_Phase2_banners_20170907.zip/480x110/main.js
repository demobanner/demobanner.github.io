var tl = new TimelineLite();
var data = ADventori.initData({
  	'img':'img.jpg',
	'location':'Luneville',
	'price':'15',
	'current':'€',
	'star':'*',
	 url:''
 
});
ADventori.Display.addAndAdaptImage(document.getElementById('img'),data.img,data.img,{fit:'cover'});
ADventori.Display.setText(document.getElementById('city_name'),data.location);
ADventori.Display.setText(document.getElementById('number'),data.price);
ADventori.Display.setText(document.getElementById('currency'),data.current);
ADventori.Display.setText(document.getElementById('star'),data.star);

function init() {

      	document.getElementById("banner").style.visibility = 'visible';

		tl.to(text1, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(text2, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        
        .to(city, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(text3, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(price, 0.5, {autoAlpha: 1, ease: Power2.easeInOut});
}

		window.onload = init;