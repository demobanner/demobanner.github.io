//tweenlite
var tl = new TimelineLite(),
    tl1 = new TimelineLite(),
    tl2 = new TimelineLite();
//adventori
var data = ADventori.initData( {
    'img':'img.jpg',
    'location':'Luneville',
    'price':'15',
    'currency':'€',
    'star':'*'
});

function init() {   
    document.getElementById("banner").style.visibility = 'visible';

    var location = data.location.toUpperCase();

    ADventori.Display.addAndAdaptImage(document.getElementById('img'),ADventori.data.img, ADventori.data.img, {fit:'cover'});
    ADventori.Display.setText(document.getElementById('city_name1'),ADventori.data.location);
    ADventori.Display.setText(document.getElementById('number1'),ADventori.data.price);
    ADventori.Display.setText(document.getElementById('currency1'),ADventori.data.currency);
    ADventori.Display.setText(document.getElementById('star1'),ADventori.data.star);

    ADventori.Display.setText(document.getElementById('city_name2'),ADventori.data.location);
    ADventori.Display.setText(document.getElementById('number2'),ADventori.data.price);
    // ADventori.Display.adaptText(document.getElementById('number2'), 40);
    ADventori.Display.setText(document.getElementById('currency2'),ADventori.data.currency);
    ADventori.Display.setText(document.getElementById('star2'),ADventori.data.star);

    ADventori.Display.setText(document.getElementById('city_name3'),ADventori.data.location);
    ADventori.Display.setText(document.getElementById('number3'),ADventori.data.price);
    // ADventori.Display.adaptText(document.getElementById('number3'), 40);
    ADventori.Display.setText(document.getElementById('currency3'),ADventori.data.currency);
    ADventori.Display.setText(document.getElementById('star3'),ADventori.data.star);

    tl.to(text11, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut, onComplete: checkPrice},'1')
        .to(text12, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(city1, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(text13, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(price1, 0.5, {autoAlpha: 1, ease: Power2.easeInOut});

    tl1.to(text21, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut},'+=1')
        .to(text22, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(city2, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(text23, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(price2, 0.5, {autoAlpha: 1, ease: Power2.easeInOut})
        .to(cta2, 0.5, {autoAlpha:1, top:90, ease:Power2.easeInOut})
        .to(logo2, 0.5, {autoAlpha:1, ease:Power2.easeInOut})
        .to(tc2, 0.5, {autoAlpha:1, ease:Power2.easeInOut});

    tl2.to(text31, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut},'+=1')
        .to(text32, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(city3, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(text33, 0.5, {autoAlpha: 1, x:0, ease: Power2.easeInOut})
        .to(price3, 0.5, {autoAlpha: 1, ease: Power2.easeInOut})
        .to(cta3, 0.5, {autoAlpha:1, top:90, ease:Power2.easeInOut})
        .to(logo3, 0.5, {autoAlpha:1, ease:Power2.easeInOut})
        .to(tc3, 0.5, {autoAlpha:1, ease:Power2.easeInOut});
}

//script
function checkPrice(){
	var price = ADventori.data.price;
	var str = price.toString();

	if(str.length > 2){
		document.getElementById("currency2").style.fontSize = "30px";
		document.getElementById("currency3").style.fontSize = "30px";
	}
}

window.onload = init;