// json2.js
"object"!=typeof JSON&&(JSON={}),function(){"use strict";function f(t){return 10>t?"0"+t:t}function quote(t){return escapable.lastIndex=0,escapable.test(t)?'"'+t.replace(escapable,function(t){var e=meta[t];return"string"==typeof e?e:"\\u"+("0000"+t.charCodeAt(0).toString(16)).slice(-4)})+'"':'"'+t+'"'}function str(t,e){var r,n,o,f,u,p=gap,a=e[t];switch(a&&"object"==typeof a&&"function"==typeof a.toJSON&&(a=a.toJSON(t)),"function"==typeof rep&&(a=rep.call(e,t,a)),typeof a){case"string":return quote(a);case"number":return isFinite(a)?a+"":"null";case"boolean":case"null":return a+"";case"object":if(!a)return"null";if(gap+=indent,u=[],"[object Array]"===Object.prototype.toString.apply(a)){for(f=a.length,r=0;f>r;r+=1)u[r]=str(r,a)||"null";return o=0===u.length?"[]":gap?"[\n"+gap+u.join(",\n"+gap)+"\n"+p+"]":"["+u.join(",")+"]",gap=p,o}if(rep&&"object"==typeof rep)for(f=rep.length,r=0;f>r;r+=1)"string"==typeof rep[r]&&(n=rep[r],o=str(n,a),o&&u.push(quote(n)+(gap?": ":":")+o));else for(n in a)Object.prototype.hasOwnProperty.call(a,n)&&(o=str(n,a),o&&u.push(quote(n)+(gap?": ":":")+o));return o=0===u.length?"{}":gap?"{\n"+gap+u.join(",\n"+gap)+"\n"+p+"}":"{"+u.join(",")+"}",gap=p,o}}"function"!=typeof Date.prototype.toJSON&&(Date.prototype.toJSON=function(){return isFinite(this.valueOf())?this.getUTCFullYear()+"-"+f(this.getUTCMonth()+1)+"-"+f(this.getUTCDate())+"T"+f(this.getUTCHours())+":"+f(this.getUTCMinutes())+":"+f(this.getUTCSeconds())+"Z":null},String.prototype.toJSON=Number.prototype.toJSON=Boolean.prototype.toJSON=function(){return this.valueOf()});var cx,escapable,gap,indent,meta,rep;"function"!=typeof JSON.stringify&&(escapable=/[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,meta={"\b":"\\b","	":"\\t","\n":"\\n","\f":"\\f","\r":"\\r",'"':'\\"',"\\":"\\\\"},JSON.stringify=function(t,e,r){var n;if(gap="",indent="","number"==typeof r)for(n=0;r>n;n+=1)indent+=" ";else"string"==typeof r&&(indent=r);if(rep=e,e&&"function"!=typeof e&&("object"!=typeof e||"number"!=typeof e.length))throw Error("JSON.stringify");return str("",{"":t})}),"function"!=typeof JSON.parse&&(cx=/[\u0000\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,JSON.parse=function(text,reviver){function walk(t,e){var r,n,o=t[e];if(o&&"object"==typeof o)for(r in o)Object.prototype.hasOwnProperty.call(o,r)&&(n=walk(o,r),void 0!==n?o[r]=n:delete o[r]);return reviver.call(t,e,o)}var j;if(text+="",cx.lastIndex=0,cx.test(text)&&(text=text.replace(cx,function(t){return"\\u"+("0000"+t.charCodeAt(0).toString(16)).slice(-4)})),/^[\],:{}\s]*$/.test(text.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g,"@").replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g,"]").replace(/(?:^|:|,)(?:\s*\[)+/g,"")))return j=eval("("+text+")"),"function"==typeof reviver?walk({"":j},""):j;throw new SyntaxError("JSON.parse")})}();

(function (ADventori, window, undefined) {

  var PrintTracker = {
    AD_ERROR_CREATIVE: 'AdErrorCreative',
    AD_ERROR_CREATIVE_MRAID: 'AdErrorCreativeMraid',
    AD_ERROR_CREATIVE_URL: 'AdErrorCreativeUrl',
    AD_ERROR_CREATIVE_MESSAGE: 'AdErrorCreativeMessage',
    AD_ERROR_OPEN: 'AdErrorOpen',
    AD_ERROR_URL: 'AdErrorUrl'
  };
  var slice = Array.prototype.slice;
  var document = window.document;

  function rand(n) {
    n = n || 2147483647;
    return Math.floor(Math.random() * n);
  }

  if (!document.getElementsByClassName) {
    document.getElementsByClassName = function (className) {
      var children = document.getElementsByTagName('*'),
          elements = [],
          classRE = new RegExp('\\b' + className + '\\b'),
          child;
      for (var i = 0, length = children.length; i < length; i++) {
        child = children[i];
        if (classRE.test(child.className)) {
          elements.push(child);
        }
      }
      return elements;
    }
  }

  /**
   * ADventori Event
   */
  (function (ADventori) {
    var _guid = 1;
    var _eventListeners = {};

    ADventori.Event = {

      addEventListener: function (el, type, fn) {
        el.ADventori_guid = el.ADventori_guid || _guid++;
        fn.ADventori_guid = fn.ADventori_guid || _guid++;
        var eventListenerId = [type, el.ADventori_guid, fn.ADventori_guid].join('_');
        if (!_eventListeners[eventListenerId]) {
          var eventListener = _eventListeners[eventListenerId] = function (e) {
            fn.apply(el, [e || window.event].concat(slice.call(arguments, 1)));
          };
          if (el.addEventListener) {
            el.addEventListener(type, eventListener, false);
          } else if (el.attachEvent) {
            el.attachEvent('on' + type, eventListener);
          }
        }
      },

      removeEventListener: function (el, type, fn) {
        var eventListenerId = [type, el.ADventori_guid, fn.ADventori_guid].join('_');
        var eventListener = _eventListeners[eventListenerId];
        if (eventListener) {
          if (el.removeEventListener) {
            el.removeEventListener(type, eventListener, false);
          } else if (el.detachEvent) {
            el.detachEvent('on' + type, eventListener);
          }
          _eventListeners[eventListenerId] = null;
        }
      },

      onReady: function (fn) {
        function readyFn() {
          if (!document.body) {
            return setTimeout(readyFn);
          }
          fn();
        }

        function completed() {
          if (document.addEventListener || event.type === 'load' || document.readyState === 'complete') {
            ADventori.Event.removeEventListener(document, document.addEventListener ? 'DOMContentLoaded' : 'readystatechange', completed);
            ADventori.Event.removeEventListener(window, 'load', completed);
            readyFn();
          }
        }

        if (document.readyState === 'complete') {
          setTimeout(readyFn);
        } else {
          ADventori.Event.addEventListener(document, document.addEventListener ? 'DOMContentLoaded' : 'readystatechange', completed);
          ADventori.Event.addEventListener(window, 'load', completed);
        }
      }

    };
  })(ADventori);

  /**
   * ADventori Macro
   */
  (function (ADventori) {

    ADventori.Macro = {

      pattern: /\[%(URI_ENCODE:)?([^\[\]]+)%\]/g,
      replace: function (str, macros) {
        if (typeof str == 'string') {
          return str.replace(ADventori.Macro.pattern, function (match, p1, p2) {
            return (macros && macros[p2] != null ? (p1 ? encodeURIComponent(macros[p2]) : macros[p2]) : '');
          });
        }
        return str;
      }

    };
  })(ADventori);

  /**
   * ADventori Core
   */
  (function (ADventori) {
    var PROTOCOL_POSTMESSAGE = 'ADventori:';

    var conf;
    var data;
    var mraidProps;
    var console;

    ADventori.commands = {};

    ADventori.exec = function (cmd, args) {
      if (conf) {
        try {
          var protocol = PROTOCOL_POSTMESSAGE;
          window.parent.postMessage(protocol + JSON.stringify({
                id: conf.id,
                cmd: cmd,
                args: slice.call(args || [])
              }), '*');
        } catch (e) {
          try {
            document.createElement('img').src = conf.track.urlError + '&tk_urlClick=' + encodeURIComponent(cmd + '|' + args + '|' + (e && e.name ? ((e.name || '') + ': ' + (e.message || '')) : e));
          } catch (_e) {
          }
        }
      }
    };

    ADventori.error = function (e, trackerType) {
      trackerType = trackerType || (conf && conf.track && conf.track.AdErrorCreative);
      if (trackerType) {
        ADventori.exec('error', [(e && e.name ? ((e.name || '') + ': ' + (e.message || '')) : e) + '', trackerType]);
      }
    };

    ADventori.open = function (url, opts) {
      if (url && url[0] == '#') {
        return 'test';
      }
      if (!url) {
        ADventori.error({name: 'NO_URL'}, PrintTracker.AD_ERROR_URL);
        return 'no_url';
      }
      if (!/^https?:\/\//.test(url)) {
        ADventori.error({name: 'NO_PROTOCOL', message: url}, PrintTracker.AD_ERROR_URL);
      }
      try {
        var newWin;
        // open target
        if (opts) {
          if (opts.target == 'top') {
            window.top.location.href = url;
            newWin = 'top';
          }
        }
        // MRAID open
        if (!newWin) {
          if (ADventori.mraid && ADventori.mraid.open) {
            ADventori.mraid.open(url);
            newWin = 'mraid';
          }
        }
        // window.open
        if (!newWin) {
          newWin = window.open(url, '_blank');
          if (newWin) {
            try {
              newWin.opener = null;
            } catch (e) {
            }
          }
        }
        // top.location
        if (!newWin) {
          window.top.location.href = url;
          newWin = 'top';
        }
        return (newWin != null && newWin == newWin.window ? 'window' : (newWin + ''));
      } catch (e) {
        ADventori.error(e, PrintTracker.AD_ERROR_OPEN);
        return 'error';
      }
    };

    ADventori.click = function (e, item, macros, opts) {
      var itemId = item && item.id != null ? encodeURIComponent(item.id) : null;
      var itemUrl = typeof item == 'string' ? item : (item && item.data && item.data.url);
      var clickTag = conf && conf.clickTag && (itemId ? conf.clickTag.replace('&URL=', ('&tk_retailer_1=' + itemId) + '&URL=') : conf.clickTag);
      var open = ADventori.open(ADventori.Macro.replace((clickTag || '') + (itemUrl || ''), macros), opts);
      ADventori.exec('click', [{"open": open, "item": item}]);
      if (e) {
        if (e.preventDefault) {
          e.preventDefault();
        } else {
          e.returnValue = false;
        }
        if (e.stopPropagation) {
          e.stopPropagation();
        } else {
          e.cancelBubble = true;
        }
      }
    };

    ADventori.initData = function (defaults) {
      data = ADventori.data = ADventori.data || defaults;
      ADventori.exec('initData', [data]);
      return data;
    };

    ADventori.log = function () {
      ADventori.exec('log', arguments);
      try {
        console && console.log && console.log.apply(console, arguments);
      } catch (e) {
      }
    };

    try {
      if (window.name) {
        var windowNameObject = JSON.parse(window.name);
        conf = ADventori.conf = windowNameObject['conf'];
        data = ADventori.data = windowNameObject['data'];
        mraidProps = ADventori.mraidProps = windowNameObject['mraid'];
      }
    } catch (e) {
    }

    try {
      window.onerror = function () {
        ADventori.error(slice.call(arguments, 0, 4).join(','));
      }
    } catch (e) {
      ADventori.error(e, PrintTracker.AD_ERROR_CREATIVE);
    }

    try {
      (function () {
        console = window.console;
        var f = ADventori.log;
        window.console = {
          log: f, info: f, warn: f, debug: f, error: f
        };
      })();
    } catch (e) {
      ADventori.error(e, PrintTracker.AD_ERROR_CREATIVE);
    }

    try {
      ADventori.Event.addEventListener(window, 'message', function (e) {
        var protocol = PROTOCOL_POSTMESSAGE;
        if (!(typeof e.data === 'string' && e.data.slice(0, protocol.length) === protocol)) {
          return;
        }
        var data = JSON.parse(e.data.slice(protocol.length));
        var fn = ADventori.commands[data.cmd] || window[data.cmd];
        if (typeof fn == 'function') {
          fn.apply(null, slice.call(data.args || []));
        } else {
          ADventori.error({
            name: 'crea.execCrea',
            message: ['INVALID_COMMAND', data && data.cmd].join(',')
          }, PrintTracker.AD_ERROR_CREATIVE_MESSAGE);
        }
      });
    } catch (e) {
      ADventori.error(e, PrintTracker.AD_ERROR_CREATIVE);
    }

    try {
      ADventori.Event.onReady(function () {
        ADventori.exec('ready');
      });
    } catch (e) {
      ADventori.error(e, PrintTracker.AD_ERROR_CREATIVE);
    }

  })(ADventori);

  /**
   * ADventori MRAID
   */
  (function (ADventori) {
    if (!ADventori.mraidProps) {
      return;
    }

    var guid = 1;
    var guidKey = 'ADventori_mraid_guid';
    var listeners = {};

    var broadcastEvent = function (event, args) {
      for (var listenerId in listeners[event]) {
        if (listeners[event][listenerId]) {
          listeners[event][listenerId].apply(null, args);
        }
      }
    };

    var broadcastError = function (name, message) {
      try {
        broadcastEvent('error', [message, name]);
      } catch (e) {
      }
      ADventori.error({
        name: name,
        message: message
      }, PrintTracker.AD_ERROR_CREATIVE_MRAID);
    };

    var addEventListener = function (event, listener) {
      if (!event || !listener) {
        broadcastError('addEventListener', 'Both event and listener are required.');
        return;
      }
      var listenerId = listener[guidKey] = listener[guidKey] || guid++;
      listeners[event] = listeners[event] || {};
      listeners[event][listenerId] = listener;
    };

    var removeEventListener = function (event, listener) {
      if (!event) {
        broadcastError('removeEventListener', 'Must specify an event.');
        return;
      }
      if (!listener) {
        for (var listenerId in listeners[event]) {
          listeners[event][listenerId] = null;
        }
        return;
      }
      var listenerId = listener[guidKey];
      if (listeners[event] && listeners[event][listenerId]) {
        listeners[event][listenerId] = null;
      }
    };

    var mraid = window.mraid = {};

    var mraidProps = ADventori.mraidProps;

    var mraidCommands = {
      'event': broadcastEvent
    };

    var mraidExec = function (cmd, args) {
      ADventori.exec('mraid', [cmd, slice.call(args || [])]);
    };

    ADventori.commands.mraid = function (cmd, args) {
      var fn = mraidCommands[cmd];
      if (fn) {
        fn.apply(null, slice.call(args || []));
      } else {
        ADventori.error({
          name: 'mraid.execCrea',
          message: ['INVALID_COMMAND', cmd].join(',')
        }, PrintTracker.AD_ERROR_CREATIVE_MRAID);
      }
    };

    ADventori.mraid = {
      open: function (url) {
        mraidExec('open', [url]);
      }
    };

    mraid.addEventListener = addEventListener;

    mraid.removeEventListener = removeEventListener;

    mraid.getState = function () {
      return mraidProps.state;
    };

    mraid.getVersion = function () {
      return mraidProps.version;
    };

    mraid.getPlacementType = function () {
      return mraidProps.placementType;
    };

    mraid.isViewable = function () {
      return mraidProps.viewable;
    };

    mraid.getCurrentPosition = function () {
      return mraidProps.currentPosition;
    };

    mraid.getDefaultPosition = function () {
      return mraidProps.defaultPosition;
    };

    mraid.getMaxSize = function () {
      return mraidProps.maxSize;
    };

    mraid.getScreenSize = function () {
      return mraidProps.screenSize;
    };

    mraid.getExpandProperties = function () {
      return mraidProps.expandProperties;
    };

    mraid.getResizeProperties = function () {
      return mraidProps.resizeProperties;
    };

    mraid.getOrientationProperties = function () {
      return mraidProps.orientationProperties;
    };

    mraid.setExpandProperties = function (props) {
      mraidProps.expandProperties = props;
    };

    mraid.setResizeProperties = function (props) {
      mraidProps.resizeProperties = props;
    };

    mraid.setOrientationProperties = function (props) {
      mraidProps.orientationProperties = props;
      mraidExec('setOrientationProperties', [props]);
    };

    mraid.useCustomClose = function (value) {
      mraidProps.useCustomClose = value;
      mraidExec('useCustomClose', [value]);
    };

    mraid.supports = function (feature) {
      return mraidProps.supports[feature];
    };

    mraid.open = function (url) {
      ADventori.click(null, url);
    };

    mraid.close = function () {
      mraidExec('close');
    };

    mraid.expand = function (url) {
      mraidExec('expand', [mraidProps.expandProperties, url]);
    };

    mraid.resize = function () {
      mraidExec('resize', [mraidProps.resizeProperties]);
    };

    mraid.createCalendarEvent = function (params) {
      mraidExec('createCalendarEvent', [params]);
    };

    mraid.storePicture = function (url) {
      mraidExec('storePicture', [url]);
    };

    mraid.playVideo = function (url) {
      mraidExec('playVideo', [url]);
    };
  })(ADventori);

  /**
   * ADventori.Display
   */
  (function (ADventori) {
    function getStyle(el, styleProp) {
      if (el.currentStyle) {
        return el.currentStyle[styleProp.replace(/-([\da-z])/gi, function (all, letter) {
          return letter.toUpperCase();
        })];
      } else if (window.getComputedStyle) {
        var style = document.defaultView.getComputedStyle(el, null);
        return style != null ? style.getPropertyValue(styleProp) : null;
      }
    }

    /*
     options: {fit: 'contain'|'cover'}
     */
    function adaptImage(options) {
      // Hidden element
      if (this.style.display == "none") {
        return;
      }

      var width = getStyle(this.parentNode, 'width'),
          pw = width && parseFloat(width),
          pwUnit = width && width.match(/[a-zA-Z]*$/)[0];
      var height = getStyle(this.parentNode, 'height'),
          ph = height && parseFloat(height),
          phUnit = height && height.match(/[a-zA-Z]*$/)[0];

      // Hidden iframe (Firefox) or detached element (Chrome)
      if (!width && !height) {
        return;
      }

      if (!pw || pwUnit != 'px' || !ph || phUnit != 'px') {
        ADventori.error({
          name: 'adaptImage',
          message: 'Unsupported width / height, pw=' + pw + ', pwUnit=' + pwUnit + ', ph=' + ph + ', phUnit=' + phUnit
        }, PrintTracker.AD_ERROR_CREATIVE);
        return;
      }

      this.parentNode.style["overflow"] = "hidden";

      var elem = this;
      var pr = pw / ph;
      var img = document.createElement('img');
      img.onload = function () {
        var w = parseFloat(getStyle(elem, 'width')),
            h = parseFloat(getStyle(elem, 'height')),
            r = w / h;

        var condition = (options.fit === 'cover') ? pr > r : pr < r;
        if (condition) {
          elem.style.width = pw + 'px';
          h = parseFloat(getStyle(elem, 'height'));
          elem.style.marginTop = -((h - ph) / 2 ) + 'px';
        } else {
          elem.style.height = ph + 'px';
          w = parseFloat(getStyle(elem, 'width'));
          elem.style.marginLeft = -((w - pw) / 2 ) + 'px';
        }
      };
      img.src = this.src;
    }

    function adaptText(minFontSizeInPx, innerHTML) {
      // Hidden element
      if (this.style.display == "none") {
        return;
      }

      var fontSize = getStyle(this, "font-size"),
          fontSizeFloat = fontSize && parseFloat(fontSize),
          fontSizeUnit = fontSize && fontSize.match(/[a-zA-Z]*$/)[0];

      // Hidden iframe (Firefox) or detached element (Chrome)
      if (!fontSize) {
        return;
      }

      if (!fontSizeFloat || fontSizeUnit != 'px') {
        ADventori.error({
          name: 'adaptText',
          message: 'Unsupported font-size, float=' + fontSizeFloat + ', unit=' + fontSizeUnit
        }, PrintTracker.AD_ERROR_CREATIVE);
        return;
      }

      var lineHeight = getStyle(this, "line-height"),
          lineHeightFloat = lineHeight && parseFloat(lineHeight),
          lineHeightUnit = lineHeight && lineHeight.match(/[a-zA-Z]*$/)[0];
      if (!lineHeightFloat || lineHeightUnit != 'px') {
        lineHeightFloat = fontSizeFloat * 1.2;
      }
      this.style.fontSize = fontSize;
      this.style.lineHeight = lineHeight;
      var min = minFontSizeInPx;
      var max = fontSizeFloat;
      var currentSize = max;
      // Reset styles text-overflow & white-space
      this.style["textOverflow"] = "clip";
      this.style["whiteSpace"] = "normal";
      var position = getStyle(this, "position");
      if (position == "static") {
        this.style["position"] = "relative";
      }

      var paddingLeft = getStyle(this, "padding-left"),
          paddingLeftFloat = paddingLeft && parseFloat(paddingLeft);
      var paddingRight = getStyle(this, "padding-right"),
          paddingRightFloat = paddingRight && parseFloat(paddingRight);
      var paddingWidth = paddingLeftFloat + paddingRightFloat;
      var paddingTop = getStyle(this, "padding-top"),
          paddingTopFloat = paddingTop && parseFloat(paddingTop);
      var paddingBottom = getStyle(this, "padding-bottom"),
          paddingBottomFloat = paddingBottom && parseFloat(paddingBottom);
      var paddingHeight = paddingTopFloat + paddingBottomFloat;

      while (currentSize >= min && ((this.scrollHeight - paddingHeight) > (this.offsetHeight - paddingHeight) || (this.scrollWidth - paddingWidth) > (this.offsetWidth - paddingWidth))) {
        this.style.fontSize = currentSize + 'px';
        this.style.lineHeight = lineHeightFloat * currentSize / max + 'px';
        currentSize = currentSize - 1;
      }

      var initialHTML = innerHTML, insertionPoint = initialHTML.length;
      var spanId = rand() + '';
      this.innerHTML = innerHTML + '<span id="' + spanId + '" style="display:inline;float:none;"></span>';
      var spanElement = document.getElementById(spanId);
      // Detached element
      if (!spanElement) {
        return;
      }
      //while the span is not complety visible
      // we push span to top
      while (insertionPoint >= 0 && (spanElement.offsetTop + spanElement.offsetHeight - paddingHeight) > (this.offsetHeight - paddingHeight)) {
        insertionPoint--;
        //manage for the balise tag
        if (initialHTML[insertionPoint] === '>') {
          while (insertionPoint >= 0 && initialHTML[insertionPoint] !== '<') {
            insertionPoint--;
          }
        }
        while (insertionPoint >= 0 && initialHTML[insertionPoint] === ' ') {
          insertionPoint--;
        }
        this.innerHTML = initialHTML.slice(0, insertionPoint) + ('<span id="' + spanId + '" style="display:inline;float:none;">…</span>');
        spanElement = document.getElementById(spanId);
      }
    }

    function verticalAlign(innerHTML) {
      var spanId = rand() + '';
      this.innerHTML = innerHTML + '<br/><span id="' + spanId + '" style="display:inline;float:none;vertical-align:middle;">.</span>';
      var spanElement = document.getElementById(spanId);
      // Detached element
      if (!spanElement) {
        return;
      }
      var paddingInPx = Math.floor((this.offsetHeight - spanElement.offsetTop) / 2) + 0.5;
      this.innerHTML = (paddingInPx > 0 ? '<span style="opacity:0;display: block; font-size:1px; line-height:' + paddingInPx + 'px;">-</span>' : '') + innerHTML;
      if (this.height < this.offsetHeight) {
        this.height = this.offsetHeight;
      }
    }

    var timerFns = [];

    var timer = 100;

    function execTimers() {
      for (var i = 0; i < timerFns.length; i++) {
        timerFns[i]();
      }
      if (timer < 10000) {
        setTimeout(execTimers, (timer = timer * 2));
      }
    }

    execTimers();

    function addToTimerFns(fn, elem) {
      if (!elem.ADventori_notFirst) {
        elem.ADventori_notFirst = true;
        elem.ADventori_innerHTML = elem.innerHTML;
        timerFns.push(function () {
          fn(elem.ADventori_innerHTML);
        });
      } else {
        timerFns.push(function () {
          fn(elem.innerHTML);
        });
      }
      fn(elem.innerHTML);
    }

    var Display = {
      setText: function (html) {
        this.innerHTML = html;
      },

      adaptText: function (minFontSizeInPx) {
        //adaptText.apply(this, arguments);
        var self = this;
        addToTimerFns(function (innerHTML) {
          adaptText.apply(self, [minFontSizeInPx, innerHTML]);
        }, this);
      },

      setAndAdaptText: function (html, minFontSizeInPx) {
        Display.setText.apply(this, [html]);
        Display.adaptText.apply(this, [minFontSizeInPx]);
      },

      verticalAlign: function () {
        //verticalAlign.apply(this, arguments);
        var self = this;
        addToTimerFns(function (innerHTML) {
          verticalAlign.apply(self, [innerHTML]);
        }, this);
      },

      setImageUrl: function (url, defaultUrl, trackError) {
        function error(message) {
          if (trackError) {
            ADventori.error({
              name: 'setImageUrl',
              message: message + ' (url=' + url + ', defaultUrl=' + defaultUrl + ')'
            }, PrintTracker.AD_ERROR_CREATIVE_URL);
          }
        }

        if (!url && !defaultUrl) {
          error('No url, no defaultUrl');
          return;
        }
        if (!url) {
          error('No url');
          url = defaultUrl;
          defaultUrl = null;
        }
        this.onerror = function () {
          error('Error loading url');
          url = defaultUrl;
          defaultUrl = null;
          if (url) {
            this.src = url;
          } else {
            this.onerror = undefined;
          }
        };
        this.src = url;
      },

      adaptImage: function (options) {
        if (typeof options == 'object') {
          adaptImage.apply(this, arguments);
        } else {
          var parent = this.parentNode;
          Display.empty.apply(parent);
          parent.className += ' adventoriImgContainer';
          Display.setImageUrl.apply(this, arguments);
          parent.appendChild(this);
        }
      },

      addImage: function () {
        var img = document.createElement('img');
        Display.setImageUrl.apply(img, arguments);
        this.appendChild(img);
      },

      addAndAdaptImage: function (url, defaultUrl, options) {
        if (typeof options == 'object') {
          Display.addImage.apply(this, arguments);
          Display.adaptImage.apply(this.lastChild, slice.call(arguments, 2));
        } else {
          Display.addImage.apply(this);
          Display.adaptImage.apply(this.lastChild, arguments);
        }
      },

      remove: function () {
        if (this.parentNode) {
          this.parentNode.removeChild(this);
        }
      },

      empty: function () {
        while (this.firstChild) {
          this.removeChild(this.firstChild);
        }
      }
    };

    ADventori.Display = ADventori.Format = {};
    for (var fn in Display) {
      (function (fn) {
        ADventori.Display[fn] = function (nodes) {
          nodes = 'length' in nodes ? nodes : [nodes];
          for (var i = 0; i < nodes.length; i++) {
            Display[fn].apply(nodes[i], slice.call(arguments, 1));
          }
          return this;
        };
      })(fn);
    }
  })(ADventori);

  /**
   * ADventori.Carousel
   */
  (function (ADventori) {
    /*
     conf: {items, hSplit, vSplit, elSlides, elBullets, cta, autoStart, interval, duration, insertHtmlStruct, carouselContainer, navPrev, navNext, hiddenBullets, animation}
     */
    var Carousel = function (conf) {
      if (!(this instanceof Carousel)) {
        return new Carousel(conf);
      }
      conf = conf || {};
      conf.items = conf.items || [];
      conf.interval = conf.interval || 3000;
      conf.duration = conf.duration || 30000;
      conf.hSplit = conf.hSplit || 1;
      conf.vSplit = conf.vSplit || 1;
      conf.onSlide = conf.onSlide || (function(){});
      this.conf = conf;
      this.slidesCount = 0;
      this.curSlide = 0;
      this.timerId = -1;
      this.started = false;
      conf.hiddenBullets = conf.hiddenBullets || false;
      conf.animation = conf.animation || "default";
      if (conf.insertHtmlStruct && conf.insertHtmlStruct == true) {
        this.makeSlide();
      }
      this.index = Carousel.instances.length;
      Carousel.instances[this.index] = this;
      this.init();

    };

    Carousel.instances = [];

    Carousel.prototype.init = function () {
      var self = this;
      window.setTimeout(function () {
        self.stop();
      }, this.conf.duration);
      this.initSlides();
      this.goto(this.curSlide);
      if (this.conf.autoStart) {
        this.start();
      }
      return this;
    };


    Carousel.prototype.makeSlide = function () {
      function setAttributes(el, options) {
        for (var attr in options) {
          el.setAttribute(attr, options[attr]);
        }
      }

      var adventoriAd = document.createElement("div");
      setAttributes(adventoriAd, {
        "id": "adventoriAd",
        "onmouseover": "carousel.pause()",
        "onmouseout": "carousel.play()"
      });
      var adventoriSlides = document.createElement("div");
      adventoriSlides.setAttribute("id", "adventoriSlides");
      this.conf.elSlides = adventoriSlides;
      var adventoriNav = document.createElement("div");
      adventoriNav.setAttribute("id", "adventoriNav");
      var adventoriBullets = document.createElement("div");
      adventoriBullets.setAttribute("id", "adventoriBullets");
      this.conf.elBullets = adventoriBullets;
      this.conf.carouselContainer ? this.conf.carouselContainer.appendChild(adventoriAd) : document.body.insertBefore(adventoriAd, document.body.firstChild);
      adventoriAd.appendChild(adventoriSlides);
      adventoriAd.appendChild(adventoriBullets);
      adventoriAd.appendChild(adventoriNav);
      //Nav Prev && Nav Next
      if (this.conf.navPrev && this.conf.navNext) {
        adventoriNav.innerHTML = "<label>" + this.conf.navPrev + "</label><label>" + this.conf.navNext + "</label>";
        var labelPrev = adventoriNav.firstChild;
        var labelNext = adventoriNav.lastChild;
        setAttributes(labelPrev, {"onclick": "carousel.prev()", "class": "prev"});
        setAttributes(labelNext, {"onclick": "carousel.next()", "class": "next"});
      }
    }

    Carousel.prototype.initSlides = function () {
      var nbItemsPerSlide = this.conf.hSplit * this.conf.vSplit;
      this.slidesCount = Math.ceil(this.conf.items.length / nbItemsPerSlide);
      var slidesHTML = '', bulletsHTML = '';
      var itemClass = 'item item' + this.conf.hSplit + 'h item' + this.conf.vSplit + 'v';
      for (var iSlide = 0; iSlide < this.slidesCount; iSlide++) {
        slidesHTML += '<div id="slide_' + this.index + '_' + iSlide + '" class="slide-container prev-active ' + this.conf.animation + '_prev"><div class="slide">';
        for (var i, iProduct = 0; iProduct < nbItemsPerSlide && (i = iSlide * nbItemsPerSlide + iProduct) < this.conf.items.length; iProduct++) {
          var item = this.conf.items[i];
          if (!(item && item.data)) {
            continue;
          }
          slidesHTML += '<a class="' + itemClass + ' item' + iProduct + '" href="' + (item.data.url || '#') + '" onclick="var carousel = ADventori.Carousel.instances[' + this.index + ']; carousel.stop(); ADventori.click(event, carousel.conf.items[' + i + ']);">';
          slidesHTML += this.initSlide(item.data);
          slidesHTML += '</a>';
        }
        slidesHTML += '</div></div>';
        bulletsHTML += '<label id="bullet_' + this.index + '_' + iSlide + '" onclick="ADventori.Carousel.instances[' + this.index + '].goto(' + iSlide + ');">●</label>';
      }

      this.conf.elSlides.innerHTML = slidesHTML;

      if (this.slidesCount > 1) {
        this.conf.elBullets.innerHTML = bulletsHTML;
      }
      else {
        document.getElementById('adventoriNav').style.display = "none";
        document.getElementById('adventoriBullets').style.display = "none";
      }
      //Hidden Bullets
      if (this.conf.hiddenBullets == true) {
        document.getElementById('adventoriBullets').style.display = "none";
      }
    };

    Carousel.prototype.initSlide = function (data) {
      var partsPrice = data.price ? data.price.split(',') : [];
      var partsOriginal_Price = data.original_price ? data.original_price.split(',') : [];
      return ('<div class="img_container"><span class="img_helper"></span><img src="' + data.img + '"></div>'
      + '<div class="name">' + data.name + '</div>'
      + '<div class="description">' + data.description + '</div>'
      + (partsOriginal_Price.length > 0 ? '<div class="original_price"><div class="barre"></div><span class="a">' + partsOriginal_Price[0] + '</span>' + (partsOriginal_Price.length > 1 ? '<span class="b">,</span>' : '') + '<span class="e">€</span>' + (partsOriginal_Price.length > 1 ? '<span class="c">' + partsOriginal_Price[1] + '</span>' : '') + '</div>' : '')
      + '<div class="price"><span class="a">' + partsPrice[0] + '</span>' + (partsPrice.length > 1 ? '<span class="b">,</span>' : '') + '<span class="e">€</span>' + (partsPrice.length > 1 ? '<span class="c">' + partsPrice[1] + '</span>' : '') + '</div>'
      + '<div class="cta">' + this.conf.cta + '</div>');
    };

    Carousel.prototype.nextSlideNo = function (i) {
      return (i + 1 < this.slidesCount) ? (i + 1) : 0;
    };

    Carousel.prototype.prevSlideNo = function (i) {
      return (i == 0) ? (this.slidesCount - 1) : (i - 1);
    };

    Carousel.prototype.goto = function (slideNo) {
      if (this.slidesCount > 0) {
        document.getElementById("slide_" + this.index + "_" + this.curSlide).className = "slide-container prev-active " + this.conf.animation + "_prev";
        if (this.slidesCount > 1) document.getElementById("bullet_" + this.index + "_" + this.curSlide).className = "";
        this.curSlide = this.prevSlideNo(this.nextSlideNo(slideNo));
        document.getElementById("slide_" + this.index + "_" + this.nextSlideNo(this.curSlide)).className = "slide-container next-active " + this.conf.animation + "_next";
        document.getElementById("slide_" + this.index + "_" + this.curSlide).className = "slide-container active " + this.conf.animation + "_active";
        if (this.slidesCount > 1) document.getElementById("bullet_" + this.index + "_" + this.curSlide).className = "active";
        this.conf.onSlide(this.curSlide);
      }
      return this;
    };

    Carousel.prototype.next = function () {
      this.goto(this.nextSlideNo(this.curSlide));
      return this;
    };

    Carousel.prototype.prev = function () {
      this.goto(this.prevSlideNo(this.curSlide));
      return this;
    };

    Carousel.prototype.play = function () {
      if (this.started && this.slidesCount > 0) {
        var self = this;
        window.clearInterval(this.timerId);
        this.timerId = window.setInterval(function () {
          self.next();
        }, this.conf.interval);
      }
      return this;
    };

    Carousel.prototype.pause = function () {
      window.clearInterval(this.timerId);
      return this;
    };

    Carousel.prototype.start = function () {
      this.started = true;
      this.play();
      return this;
    };

    Carousel.prototype.stop = function () {
      this.started = false;
      this.pause();
      return this;
    };

    ADventori.Carousel = Carousel;
  })(ADventori);
  /**
   * ADventori.Video
   */
  (function (ADventori) {
    var Video = function (conf) {
      if (!(this instanceof Video)) {
        return new Video(conf);
      }
      conf = conf || {};
      conf.videoElement = conf.videoElement || null;
      conf.urlMp4 = conf.urlMp4 || undefined;
      conf.urlWebM = conf.urlWebM || undefined;
      conf.autoplay = conf.autoplay || false;
      conf.showControls = conf.showControls || false;
      conf.sound = conf.sound || false;
      conf.cssStyle = conf.cssStyle || undefined;
      conf.clicUrl = conf.clicUrl || null;
      this.conf = conf;
      this.init();
    };

    Video.prototype.init = function () {
      var self = this;
      this.makeVideo();
      return this;
    };

    Video.prototype.makeVideo = function () {
      var flagGWD = false, flagEdge = false, flagHTML = false;

      function setAttributes(el, options) {
        for (var attr in options) {
          el.setAttribute(attr, options[attr]);
        }
      }

      var bounds;
      if (this.conf.videoContainer.width != null) {
        //edge
        bounds = {
          "width": parseInt(this.conf.videoContainer.width()),
          "height": parseInt(this.conf.videoContainer.height())
        };
        flagEdge = true;
      } else {
        if (this.conf.videoContainer.style.width == "") {
          //GWD
          bounds = {
            "width": parseInt(getComputedStyle(this.conf.videoContainer).width),
            "height": parseInt(getComputedStyle(this.conf.videoContainer).height)
          };
          flagGWD = true;
        } else {
          //html5
          bounds = {
            "width": parseInt(this.conf.videoContainer.style.width),
            "height": parseInt(this.conf.videoContainer.style.height)
          };
          flagHTML = true;
        }
      }
      var container = document.createElement("div");
      var isMSIE = /*@cc_on!@*/0;
      if (flagEdge == true || flagGWD == true && isMSIE && navigator.appVersion.indexOf("MSIE 10") == -1) {
        this.conf.videoContainer.append(container);
      } else {
        this.conf.videoContainer.appendChild(container);
      }
      container.style.visibility = "visible";
      container.style.position = "relative";
      container.style.left = 0;
      container.style.top = 0;
      container.style.overflow = "auto";
      var video = document.createElement('video');
      video.width = bounds.width - 2;
      video.height = bounds.height;
      this.conf.videoElement = video;
      if (this.conf.showControls != undefined) {
        (this.conf.showControls == true || this.conf.showControls == "true") ? (video.setAttribute("controls", "controls")) : (video.removeAttribute("controls"));
      }
      if (this.conf.autoplay != undefined) {
        (this.conf.autoplay == true || this.conf.autoplay == "true" ) ? ( video.autoPlay = true, video.autoplay = "autoplay", video.onloadstart = function () {
          video.play();
        }) : (video.autoPlay = false);
        if (flagGWD) {
          video.addEventListener("seeked", function () {
            video.play();
          }, true);
          if (isMSIE || (navigator.appName == "Netscape")) {
            video.oncanplaythrough = function () {
              video.play();
            }
          }
          if (navigator.userAgent.toLowerCase().indexOf('firefox') > -1) {
            video.oncanplaythrough = function () {
              video.play();
            }
            video.currentTime = 1.0;
          }
        }
      }
      (this.conf.sound == false || this.conf.sound == "false") ? (video.muted = true) : null;
      if (this.conf.urlMp4) {
        var mp4Url = document.createElement("source");
        mp4Url.type = "video/mp4";
        mp4Url.src = this.conf.urlMp4;
        video.appendChild(mp4Url);
        container.appendChild(video);
      }
      if (this.conf.urlWebM) {
        var webMUrl = document.createElement("source");
        webMUrl.type = "video/webm";
        webMUrl.src = this.conf.urlWebM;
        video.appendChild(webMUrl);
        container.appendChild(video);
      }

      if (this.conf.cssStyle) {
        var cssPair;
        var cssStyles = this.conf.cssStyle.split(";");
        var i = cssStyles.length;
        while (i) {
          cssPair = cssStyles[--i].split("=");
          if (cssPair.length == 2) {
            video.style[cssPair[0].trim()] = cssPair[1].trim();
          }
        }
      }
      if (this.conf.clicUrl != undefined) {
        this.conf.videoContainer.style.cursor = "pointer";
        var self = this;
        this.conf.videoContainer.onclick = function (e) {
          ADventori.click(e, self.conf.clicUrl);
          (self.conf.showControls == true) ? self.conf.videoElement.pause() : '';
        };
      }
    }

    Video.prototype.play = function () {
      var self = this;
      self.conf.videoElement.play();
      return this;
    };

    Video.prototype.pause = function () {
      var self = this;
      self.conf.videoElement.pause();
      return this;
    };
    ADventori.Video = Video;
  })(ADventori);

})
(window.ADventori = window.ADventori || {}, window);
