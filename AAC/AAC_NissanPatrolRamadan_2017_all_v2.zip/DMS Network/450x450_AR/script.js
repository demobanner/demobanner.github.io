//var tl = new TimelineLite();

function onLoadHandler(e){
	var floatCon = document.getElementById('floater_dc');
	var closeBtn = document.getElementById('close_btn_dc');
	var replayBtn = document.getElementById('btn_replay');
	var bgExtBtn = document.getElementById('background_ext_dc')

	if (Enabler.isInitialized()) {
	    enablerInitHandler();
	} else {
	    Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
	}

	function enablerInitHandler() {
    	Enabler.setFloatingPixelDimensions(450,450);

    	floatCon.style.display = 'block';

		var autoTimer = setInterval(autoClose, 30000);

		function autoClose() {
		  clearInterval(autoTimer);
		  Enabler.close();
		}

		function onCloseHandler(e){
			clearInterval(autoTimer);
			Enabler.reportManualClose();
			Enabler.close();
		}

		function onReplayHandler (e) {
			tl.restart();
		}

		function onBgExitHandler(e){
			clearInterval(autoTimer);
			Enabler.exit('HTML5_Background_Clickthrough');
			Enabler.close();
		}

		closeBtn.addEventListener('click', onCloseHandler, false);
		replayBtn.addEventListener('click', onReplayHandler, false);
		bgExtBtn.addEventListener('click', onBgExitHandler, false);

		init();
	}
}

function init() {

    //var tl = new TimelineLite();

		tl.to(f2_text, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(f2_text, 0.5, {autoAlpha:0, ease:Power3.easeInOut}, "+=2")

				.fromTo(f3_car, 0.5, {autoAlpha:1, x:-334, y:-20}, {x:0, y:0, ease:Power1.easeInOut})
				.to(wheels, 0.1, {autoAlpha:0, ease:Power1.easeInOut}, "-=0.1")
				.to(wheels, 0.1, {autoAlpha:1, ease:Power1.easeInOut}, "+=1")
				 .to(f3_car, 0.5, {x:432, y:20, ease:Power1.easeInOut})

				.to(f4_text, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(f4_text, 0.5, {autoAlpha:0, ease:Power3.easeInOut}, "+=2")

				.to(f5_text, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(f5_text, 0.5, {autoAlpha:0, ease:Power3.easeInOut}, "+=2")

				.to(f6_text, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(f6_text, 0.5, {autoAlpha:0, ease:Power3.easeInOut}, "+=2")

				.fromTo(f7_car, 0.5, {autoAlpha:1, scale:0.85, x:-333, y:-20}, {x:-5, y:-23, ease:Power1.easeOut})
				.to(wheels, 0.1, {autoAlpha:0, ease:Power1.easeInOut}, "-=0.1")

				.to(f8_text, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(logo_awr, 0.5, {autoAlpha:1, ease:Power3.easeInOut})
				.to(cta, 0.5, {autoAlpha:1, top:0, ease:Power3.easeInOut})
				.to(tc, 0.5, {autoAlpha:1, ease:Power3.easeInOut});

			tl.fromTo(stars, 13, {x:-332}, {x:0, ease:Linear.easeNone}, '0');

   			tl.to(btn_replay, 0.5, {autoAlpha: 1, rotation: 180});
}

window.addEventListener('load', onLoadHandler);
