
function onLoadHandler(e){
	var floatCon = document.getElementById('floater_dc');
	var closeBtn = document.getElementById('close_btn_dc');
	var bgExtBtn = document.getElementById('background_ext_dc')

	if (Enabler.isInitialized()) {
	    enablerInitHandler();
	} else {
	    Enabler.addEventListener(studio.events.StudioEvent.INIT, enablerInitHandler);
	}

	function enablerInitHandler() {
    	Enabler.setFloatingPixelDimensions(768,1024);

    	floatCon.style.display = 'block';

		var autoTimer = setInterval(autoClose, 30000);

		function autoClose() {
		  clearInterval(autoTimer);
		  Enabler.close();
		}

		function onCloseHandler(e){
			clearInterval(autoTimer);
			Enabler.reportManualClose();
			Enabler.close();
		}

		function onBgExitHandler(e){
			clearInterval(autoTimer);
			Enabler.exit('HTML5_Background_Clickthrough');
			Enabler.close();
		}

		closeBtn.addEventListener('click', onCloseHandler, false);
		bgExtBtn.addEventListener('click', onBgExitHandler, false);

		init();
	}
}

function init() {
        var car1 = document.getElementById("car1"),
				logo = document.getElementById("logo"),
				mobile = document.getElementById("mobile"),
				f1_text = document.getElementById("f1_text"),
				f2_text = document.getElementById("f2_text"),
				finger = document.getElementById("finger"),
				f3_lights = document.getElementById("f3_lights"),
				f4_text = document.getElementById("f4_text"),
				f5_lights = document.getElementById("f5_lights"),
				f6_text = document.getElementById("f6_text"),
				maps = document.getElementById("maps"),
				logo1_end = document.getElementById("logo1_end"),
				logo2_end = document.getElementById("logo2_end"),
				cta = document.getElementById("cta"),
				text_end = document.getElementById("text_end"),
				tc = document.getElementById("tc");

    var tl = new TimelineLite();

		tl.to(f1_text, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(f1_text, 0.5, {autoAlpha: 0, ease: Power1.easeInOut, delay: 2});

			tl.to(f2_text, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(finger, 0.5, {left: 0, ease: Power1.easeInOut})
				.to(f3_lights, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to([f3_lights, f2_text], 0.5, {autoAlpha: 0, ease: Power1.easeInOut, delay: 2});

			tl.to(finger, 0.5, {top: -55, left: 49, ease: Power1.easeInOut})
				.to(f4_text, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(finger, 0.5, {top: -17, left: 65, ease: Power1.easeInOut}, "+=0.5")
				.to(f5_lights, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(finger, 0.5, {top: 3, left: 65, ease: Power1.easeInOut, delay: 2})
				.to([f4_text, f5_lights, car1], 0.5, {autoAlpha: 0, ease: Power3.easeInOut});

			tl.to(finger, 0.5, {top: 50, left: 40, ease: Power1.easeInOut})
				.to(f6_text, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(maps, 0.5, {autoAlpha: 1, ease: Power1.easeInOut}, "-=0.5")
				.to(mask, 0.5, {autoAlpha: 1, ease: Power1.easeInOut}, "-=1")
				.to(car2, 0.5, {autoAlpha: 1, ease: Power1.easeInOut}, "-=0.5")
				.to(mask, 0.5, {scale: 3, autoAlpha: 0, ease: Power2.easeInOut}, "-=0.25");

			tl.to([logo, mobile, maps, f6_text, mask, car2, car1, finger, bg_black], 0.5, {autoAlpha: 0, ease: Power1.easeInOut, delay: 2})
				.to(logo1_end, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(text_end, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(cta, 0.5, {autoAlpha: 1, top: 0, ease: Power1.easeInOut})
				.to(logo2_end, 0.5, {autoAlpha: 1, ease: Power1.easeInOut})
				.to(tc, 0.3, {autoAlpha: 1, ease: Power1.easeInOut});
}

window.addEventListener('load', onLoadHandler);
